﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Pirogenoe p = new Pirogenoe();
            p.pir = textBox1.Text;
            p.t = textBox2.Text;
            p.krem = textBox3.Text;
            p.ves= (double)(numericUpDown1.Value);
            p.kal = (double)(numericUpDown2.Value);
            p.cena = (double)(numericUpDown3.Value);
            p.k = (double)(numericUpDown4.Value);
            string f = Convert.ToString(textBox1.Text) + " " + Convert.ToString(textBox2.Text) + " " + Convert.ToString(textBox3.Text) + " " + Convert.ToString(numericUpDown1.Value) + " " + Convert.ToString(numericUpDown2.Value) + " " + Convert.ToString(numericUpDown3.Value) + " " + Convert.ToString(numericUpDown4.Value);
           if (listBox1.Items.Contains(f))
            {
                MessageBox.Show("добавленное значение уже присутсвует в списке");
            }
            else 
            listBox1.Items.Add(f);
        }
       

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Pirogenoe p = new Pirogenoe();
            p.pir = textBox1.Text;
            p.t = textBox2.Text;
            p.krem = textBox3.Text;
            p.ves = (double)(numericUpDown1.Value);
            p.kal = (double)(numericUpDown2.Value);
            p.cena = (double)(numericUpDown3.Value);
            p.k = (double)(numericUpDown4.Value);
            listBox1.Items.Add("Пироженое-" + p.pir + " стоит :" + p.eda());
            
           
        }
    }
    class Pirogenoe
    {
        public string pir;
        public string t;
        public string krem;
        public double ves;
        public double kal;
        public double cena;
        public double k;
       
        public double eda()
        {
           
             cena = cena * k;
             return cena;
        }  
       

      
    }
}
